import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Truck,
  Shield,
  RotateCcw,
  Headphones,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
} from 'lucide-react';

const features = [
  {
    icon: Truck,
    title: 'شحن سريع',
    description: 'توصيل خلال 24-48 ساعة لجميع المدن',
  },
  {
    icon: Shield,
    title: 'دفع آمن',
    description: 'نظام دفع مشفر وآمن 100%',
  },
  {
    icon: RotateCcw,
    title: 'إرجاع سهل',
    description: 'سياسة إرجاع مرنة خلال 14 يوم',
  },
  {
    icon: Headphones,
    title: 'دعم 24/7',
    description: 'فريق دعم جاهز لمساعدتك دائماً',
  },
];

const quickLinks = [
  { name: 'من نحن', href: '/about' },
  { name: 'سياسة الخصوصية', href: '#' },
  { name: 'الشروط والأحكام', href: '#' },
  { name: 'سياسة الإرجاع', href: '#' },
  { name: 'الأسئلة الشائعة', href: '#' },
];

export function Footer() {
  return (
    <footer className="bg-white">
      {/* Features */}
      <div className="border-t">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-12 h-12 bg-[#7c3aed]/10 rounded-xl flex items-center justify-center shrink-0">
                  <feature.icon className="w-6 h-6 text-[#7c3aed]" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm mb-1">{feature.title}</h3>
                  <p className="text-xs text-gray-500">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="bg-[#1a1a2e] text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* About */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-[#7c3aed] rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-xl">أ</span>
                </div>
                <span className="text-xl font-bold">أصالة</span>
              </div>
              <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                منصة تسوق إلكتروني رائدة تقدم تجربة تسوق فريدة مع مجموعة واسعة من المنتجات عالية الجودة.
              </p>
              <div className="flex gap-2">
                {[Facebook, Twitter, Instagram, Youtube].map((Icon, index) => (
                  <a
                    key={index}
                    href="#"
                    className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#7c3aed] transition-colors"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold mb-4">روابط سريعة</h3>
              <ul className="space-y-2">
                {quickLinks.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.href}
                      className="text-gray-400 text-sm hover:text-white transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-semibold mb-4">تواصل معنا</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-gray-400 text-sm">
                  <MapPin className="w-4 h-4 text-[#7c3aed]" />
                  الرياض، المملكة العربية السعودية
                </li>
                <li className="flex items-center gap-2 text-gray-400 text-sm">
                  <Phone className="w-4 h-4 text-[#7c3aed]" />
                  9200xxxx
                </li>
                <li className="flex items-center gap-2 text-gray-400 text-sm">
                  <Mail className="w-4 h-4 text-[#7c3aed]" />
                  info@asalah.com
                </li>
              </ul>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="font-semibold mb-4">النشرة البريدية</h3>
              <p className="text-gray-400 text-sm mb-3">
                اشترك للحصول على أحدث العروض
              </p>
              <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}>
                <Input
                  type="email"
                  placeholder="بريدك الإلكتروني"
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                />
                <Button className="bg-[#7c3aed] hover:bg-[#6d28d9] shrink-0">
                  اشتراك
                </Button>
              </form>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10">
          <div className="container mx-auto px-4 py-4">
            <p className="text-center text-gray-400 text-sm">
              جميع الحقوق محفوظة © 2024 أصالة
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
