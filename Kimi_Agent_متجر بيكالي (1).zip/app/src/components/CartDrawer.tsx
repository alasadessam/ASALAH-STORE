import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  ShoppingCart,
  Trash2,
  Plus,
  Minus,
  ArrowLeft,
  Package,
} from 'lucide-react';

export function CartDrawer() {
  const navigate = useNavigate();
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateQuantity,
    getCartTotal,
  } = useStore();

  const cartTotal = getCartTotal();
  const shippingCost = cartTotal > 500 ? 0 : 30;
  const finalTotal = cartTotal + shippingCost;

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent side="left" className="w-full sm:max-w-md flex flex-col">
        <SheetHeader className="space-y-2.5 pb-4 border-b">
          <SheetTitle className="flex items-center gap-2 text-xl">
            <ShoppingCart className="w-6 h-6 text-[#7c3aed]" />
            سلة التسوق
            <span className="text-sm font-normal text-gray-500">
              ({cart.length} منتج)
            </span>
          </SheetTitle>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Package className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold mb-2">السلة فارغة</h3>
            <p className="text-gray-500 mb-6">
              ابدأ التسوق واكتشف منتجاتنا الرائعة
            </p>
            <Button 
              className="bg-[#7c3aed] hover:bg-[#6d28d9]"
              onClick={() => {
                setIsCartOpen(false);
                navigate('/products');
              }}
            >
              تصفح المنتجات
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 -mx-6 px-6">
              <div className="space-y-4 py-4">
                <AnimatePresence mode="popLayout">
                  {cart.map((item: { product: { id: number; image: string; name: string; price: number }; quantity: number }) => (
                    <motion.div
                      key={item.product.id}
                      layout
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="flex gap-4 p-3 rounded-xl bg-gray-50"
                    >
                      {/* Image */}
                      <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0 bg-white">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm line-clamp-1 mb-1">
                          {item.product.name}
                        </h4>
                        <p className="text-[#7c3aed] font-semibold mb-2">
                          {item.product.price} ريال
                        </p>

                        <div className="flex items-center justify-between">
                          {/* Quantity */}
                          <div className="flex items-center gap-1 bg-white rounded-lg border">
                            <button
                              onClick={() =>
                                updateQuantity(item.product.id, item.quantity - 1)
                              }
                              className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-lg transition-colors"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center text-sm font-medium">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() =>
                                updateQuantity(item.product.id, item.quantity + 1)
                              }
                              className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-lg transition-colors"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Remove */}
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="w-8 h-8 flex items-center justify-center text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </ScrollArea>

            <div className="border-t pt-4 space-y-4">
              {/* Summary */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">المجموع الفرعي</span>
                  <span>{cartTotal.toFixed(2)} ريال</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">الشحن</span>
                  <span className={shippingCost === 0 ? 'text-green-500' : ''}>
                    {shippingCost === 0 ? 'مجاني' : `${shippingCost} ريال`}
                  </span>
                </div>
                {shippingCost > 0 && (
                  <p className="text-xs text-gray-400">
                    أضف منتجات بقيمة {(500 - cartTotal).toFixed(0)} ريال للحصول على توصيل مجاني
                  </p>
                )}
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>الإجمالي</span>
                  <span className="text-[#7c3aed]">{finalTotal.toFixed(2)} ريال</span>
                </div>
              </div>

              {/* Actions */}
              <Button
                className="w-full bg-[#7c3aed] hover:bg-[#6d28d9]"
                size="lg"
                onClick={() => {
                  setIsCartOpen(false);
                  navigate('/checkout');
                }}
              >
                إتمام الطلب
                <ArrowLeft className="w-4 h-4 mr-2" />
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
