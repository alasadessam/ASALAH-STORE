import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mail, Phone, MapPin, Clock, Send, Check, MessageCircle, Headphones, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const contactInfo = [
  { icon: Phone, title: 'اتصل بنا', content: '+966 50 123 4567', subContent: 'متاح على واتساب' },
  { icon: Mail, title: 'البريد الإلكتروني', content: 'support@asalah.com', subContent: 'نرد خلال 24 ساعة' },
  { icon: MapPin, title: 'العنوان', content: 'الرياض، المملكة العربية السعودية', subContent: 'حي العليا، برج المملكة' },
  { icon: Clock, title: 'ساعات العمل', content: 'السبت - الخميس', subContent: '9:00 ص - 9:00 م' },
];

const faqs = [
  { question: 'كم تستغرق عملية التوصيل؟', answer: 'التوصيل يستغرق 2-3 أيام عمل في المدن الرئيسية و3-5 أيام في المدن الأخرى.' },
  { question: 'هل يمكنني إرجاع المنتج؟', answer: 'نعم، يمكنك إرجاع المنتج خلال 14 يوم من تاريخ الاستلام.' },
  { question: 'ما هي طرق الدفع المتاحة؟', answer: 'نقبل الدفع عند الاستلام، البطاقات الائتمانية، وApple Pay.' },
  { question: 'هل هناك حد أدنى للطلب؟', answer: 'لا يوجد حد أدنى. للحصول على توصيل مجاني، يجب أن يكون الطلب فوق 500 ريال.' },
];

export function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="mb-4 bg-[#7c3aed]">تواصل معنا</Badge>
            <h1 className="text-4xl font-bold mb-4">نحن هنا لمساعدتك</h1>
            <p className="text-gray-500 max-w-2xl mx-auto">
              لديك سؤال أو استفسار؟ فريقنا جاهز لمساعدتك
            </p>
          </motion.div>
        </div>

        {/* Contact Info Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {contactInfo.map((info, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full text-center">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-[#7c3aed]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <info.icon className="w-7 h-7 text-[#7c3aed]" />
                  </div>
                  <h3 className="font-semibold mb-1">{info.title}</h3>
                  <p className="text-sm font-medium">{info.content}</p>
                  <p className="text-xs text-gray-500">{info.subContent}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-[#7c3aed]/10 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 text-[#7c3aed]" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">أرسل لنا رسالة</h2>
                    <p className="text-sm text-gray-500">سنعود إليك في أقرب وقت</p>
                  </div>
                </div>

                {isSubmitted ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">تم الإرسال بنجاح!</h3>
                    <p className="text-gray-500">شكراً لتواصلك معنا</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">الاسم *</Label>
                        <Input id="name" placeholder="محمد أحمد" required />
                      </div>
                      <div>
                        <Label htmlFor="email">البريد الإلكتروني *</Label>
                        <Input id="email" type="email" placeholder="example@email.com" required />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="subject">الموضوع *</Label>
                      <Input id="subject" placeholder="استفسار عن طلب" required />
                    </div>
                    <div>
                      <Label htmlFor="message">الرسالة *</Label>
                      <Textarea id="message" placeholder="اكتب رسالتك هنا..." rows={5} required />
                    </div>
                    <Button type="submit" className="w-full bg-[#7c3aed] hover:bg-[#6d28d9]">
                      <Send className="w-5 h-5 ml-2" />
                      إرسال الرسالة
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Live Chat & Social */}
          <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }} className="space-y-6">
            <Card className="bg-[#7c3aed] text-white">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center">
                    <Headphones className="w-7 h-7" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1">دعم مباشر</h3>
                    <p className="text-white/80 mb-4">تحدث مع فريق الدعم للحصول على مساعدة فورية</p>
                    <Button variant="secondary" className="w-full sm:w-auto">
                      <MessageCircle className="w-5 h-5 ml-2" />
                      بدء المحادثة
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold mb-4">تابعنا على</h3>
                <div className="flex gap-3">
                  {[Facebook, Twitter, Instagram, Youtube].map((Icon, index) => (
                    <a
                      key={index}
                      href="#"
                      className="flex-1 flex flex-col items-center gap-2 p-4 rounded-xl bg-gray-50 hover:bg-[#7c3aed]/10 transition-colors group"
                    >
                      <Icon className="w-6 h-6 text-gray-400 group-hover:text-[#7c3aed] transition-colors" />
                    </a>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* FAQ */}
        <div className="mt-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">الأسئلة الشائعة</h2>
            <p className="text-gray-500">إجابات على أكثر الأسئلة شيوعاً</p>
          </div>

          <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-2">{faq.question}</h4>
                    <p className="text-sm text-gray-500">{faq.answer}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
