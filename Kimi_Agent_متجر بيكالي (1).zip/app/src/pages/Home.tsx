import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { categories, products } from '@/data/products';
import { ProductCard } from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { 
  Headphones, 
  Shirt, 
  Home as HomeIcon, 
  Dumbbell,
  ArrowLeft,
  ShoppingBag,
  Truck,
  Shield,
  RotateCcw,
  HeadphonesIcon,
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  Headphones,
  Shirt,
  Home: HomeIcon,
  Dumbbell,
};

const features = [
  { icon: Truck, title: 'شحن سريع', desc: 'توصيل خلال 24-48 ساعة' },
  { icon: Shield, title: 'دفع آمن', desc: 'نظام دفع مشفر 100%' },
  { icon: RotateCcw, title: 'إرجاع سهل', desc: 'سياسة إرجاع مرنة' },
  { icon: HeadphonesIcon, title: 'دعم 24/7', desc: 'فريق دعم جاهز' },
];

export function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1a1a2e] via-[#1a1a2e] to-[#7c3aed]/20 py-16 lg:py-24 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center lg:text-right"
            >
              <span className="inline-block bg-[#7c3aed]/20 text-[#7c3aed] px-4 py-2 rounded-full text-sm font-medium mb-6">
                ✨ اكتشف أصالة التسوق الإلكتروني
              </span>
              <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                تجربة تسوق
                <span className="text-[#7c3aed] block mt-2">فريدة ومميزة</span>
              </h1>
              <p className="text-gray-400 text-lg mb-8 max-w-xl mx-auto lg:mx-0">
                أحدث المنتجات بأفضل الأسعار مع توصيل سريع لباب منزلك. جودة عالية وأسعار منافسة.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button
                  size="lg"
                  className="bg-[#7c3aed] hover:bg-[#6d28d9] text-lg px-8"
                  onClick={() => navigate('/products')}
                >
                  <ShoppingBag className="w-5 h-5 ml-2" />
                  تسوق الآن
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/30 text-white hover:bg-white/10 text-lg px-8"
                  onClick={() => navigate('/products')}
                >
                  اكتشف المزيد
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-[#7c3aed]/30 rounded-3xl blur-3xl" />
                <img
                  src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800"
                  alt="Shopping"
                  className="relative z-10 w-full rounded-3xl shadow-2xl"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">تسوق حسب الفئة</h2>
            <p className="text-gray-500">اختر الفئة التي تناسبك</p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {categories.map((category, index) => {
              const Icon = iconMap[category.icon] || ShoppingBag;
              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link
                    to={`/products?category=${category.id}`}
                    className="group block bg-white rounded-2xl p-6 text-center hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="w-16 h-16 bg-[#7c3aed]/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-[#7c3aed] transition-colors">
                      <Icon className="w-8 h-8 text-[#7c3aed] group-hover:text-white transition-colors" />
                    </div>
                    <h3 className="font-semibold text-lg mb-1">{category.name}</h3>
                    <p className="text-sm text-gray-500">{category.description}</p>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-2">منتجات مميزة</h2>
              <p className="text-gray-500">اخترنا لك بعناية</p>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate('/products')}
              className="hidden sm:flex"
            >
              عرض الكل
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            {products.slice(0, 8).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Button variant="outline" onClick={() => navigate('/products')}>
              عرض الكل
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-[#1a1a2e]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-14 h-14 bg-[#7c3aed]/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-7 h-7 text-[#7c3aed]" />
                </div>
                <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                <p className="text-sm text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#7c3aed] to-[#6d28d9]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            جاهز للتسوق؟
          </h2>
          <p className="text-white/80 mb-8 max-w-2xl mx-auto">
            انضم إلى آلاف العملاء السعداء واكتشف عالماً من المنتجات الرائعة
          </p>
          <Button
            size="lg"
            variant="secondary"
            onClick={() => navigate('/products')}
          >
            ابدأ التسوق الآن
            <ArrowLeft className="w-5 h-5 mr-2" />
          </Button>
        </div>
      </section>
    </div>
  );
}
