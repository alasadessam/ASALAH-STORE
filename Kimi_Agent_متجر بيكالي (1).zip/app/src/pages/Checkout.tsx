import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  ArrowLeft,
  ArrowRight,
  MapPin,
  CreditCard,
  Check,
  Shield,
  Lock,
  Package,
} from 'lucide-react';

const cities = [
  'الرياض',
  'جدة',
  'مكة المكرمة',
  'المدينة المنورة',
  'الدمام',
  'الخبر',
  'الطائف',
  'تبوك',
];

const paymentMethods = [
  { id: 'cod', name: 'الدفع عند الاستلام', icon: Package },
  { id: 'card', name: 'بطاقة ائتمانية', icon: CreditCard },
];

export function Checkout() {
  const navigate = useNavigate();
  const { cart, getCartTotal, clearCart } = useStore();

  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    city: '',
    district: '',
    street: '',
    building: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('cod');

  const cartTotal = getCartTotal();
  const shippingCost = cartTotal > 500 ? 0 : 30;
  const finalTotal = cartTotal + shippingCost;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    setIsProcessing(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setIsComplete(true);
    clearCart();
  };

  const isStep1Valid = () => {
    return formData.fullName && formData.phone && formData.city && formData.district && formData.street;
  };

  if (cart.length === 0 && !isComplete) {
    navigate('/cart');
    return null;
  }

  if (isComplete) {
    return (
      <div className="min-h-screen py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto text-center"
          >
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold mb-3">تم تأكيد طلبك!</h1>
            <p className="text-gray-500 mb-6">
              شكراً لك على طلبك. رقم الطلب: <strong>#ORD-{Date.now()}</strong>
            </p>
            <div className="space-y-3">
              <Button className="w-full bg-[#7c3aed] hover:bg-[#6d28d9]" onClick={() => navigate('/products')}>
                مواصلة التسوق
              </Button>
              <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                العودة للرئيسية
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => step > 1 ? setStep(1) : navigate('/cart')}>
            <ArrowRight className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">إتمام الطلب</h1>
            <p className="text-gray-500">الخطوة {step} من 2</p>
          </div>
        </div>

        {/* Progress */}
        <div className="flex gap-2 mb-8">
          <div className={`flex-1 h-2 rounded-full ${step >= 1 ? 'bg-[#7c3aed]' : 'bg-gray-200'}`} />
          <div className={`flex-1 h-2 rounded-full ${step >= 2 ? 'bg-[#7c3aed]' : 'bg-gray-200'}`} />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {step === 1 ? (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 bg-[#7c3aed]/10 rounded-full flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-[#7c3aed]" />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold">عنوان التوصيل</h2>
                        <p className="text-sm text-gray-500">أدخل عنوان التوصيل</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="md:col-span-2">
                        <Label htmlFor="fullName">الاسم الكامل *</Label>
                        <Input
                          id="fullName"
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="محمد أحمد"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">رقم الجوال *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="05xxxxxxxx"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">البريد الإلكتروني</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="example@email.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="city">المدينة *</Label>
                        <select
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          className="w-full h-10 px-3 rounded-md border border-input bg-background"
                        >
                          <option value="">اختر المدينة</option>
                          {cities.map((city) => (
                            <option key={city} value={city}>{city}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="district">الحي *</Label>
                        <Input
                          id="district"
                          name="district"
                          value={formData.district}
                          onChange={handleInputChange}
                          placeholder="حي النزهة"
                        />
                      </div>
                      <div>
                        <Label htmlFor="street">الشارع *</Label>
                        <Input
                          id="street"
                          name="street"
                          value={formData.street}
                          onChange={handleInputChange}
                          placeholder="شارع الملك فهد"
                        />
                      </div>
                      <div>
                        <Label htmlFor="building">رقم المبنى</Label>
                        <Input
                          id="building"
                          name="building"
                          value={formData.building}
                          onChange={handleInputChange}
                          placeholder="1234"
                        />
                      </div>
                    </div>

                    <Button
                      className="w-full mt-6 bg-[#7c3aed] hover:bg-[#6d28d9]"
                      size="lg"
                      disabled={!isStep1Valid()}
                      onClick={() => setStep(2)}
                    >
                      متابعة
                      <ArrowLeft className="w-5 h-5 mr-2" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 bg-[#7c3aed]/10 rounded-full flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-[#7c3aed]" />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold">طريقة الدفع</h2>
                        <p className="text-sm text-gray-500">اختر طريقة الدفع المناسبة</p>
                      </div>
                    </div>

                    <RadioGroup
                      value={paymentMethod}
                      onValueChange={setPaymentMethod}
                      className="space-y-3"
                    >
                      {paymentMethods.map((method) => (
                        <label
                          key={method.id}
                          className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                            paymentMethod === method.id
                              ? 'border-[#7c3aed] bg-[#7c3aed]/5'
                              : 'border-gray-200 hover:border-[#7c3aed]/50'
                          }`}
                        >
                          <RadioGroupItem value={method.id} id={method.id} />
                          <div className="w-12 h-12 bg-[#7c3aed]/10 rounded-full flex items-center justify-center">
                            <method.icon className="w-6 h-6 text-[#7c3aed]" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold">{method.name}</h3>
                          </div>
                        </label>
                      ))}
                    </RadioGroup>

                    <div className="flex gap-3 mt-6">
                      <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>
                        <ArrowRight className="w-5 h-5 ml-2" />
                        رجوع
                      </Button>
                      <Button
                        className="flex-1 bg-[#7c3aed] hover:bg-[#6d28d9]"
                        size="lg"
                        onClick={handleSubmit}
                        disabled={isProcessing}
                      >
                        {isProcessing ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin ml-2" />
                            جاري المعالجة...
                          </>
                        ) : (
                          <>
                            تأكيد الطلب
                            <Lock className="w-5 h-5 mr-2" />
                          </>
                        )}
                      </Button>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4 text-sm text-gray-500">
                      <Shield className="w-4 h-4" />
                      دفع آمن ومشفر 100%
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">ملخص الطلبية</h2>

                  <div className="space-y-3 mb-4 max-h-40 overflow-y-auto">
                    {cart.map((item: { product: { id: number; image: string; name: string; price: number }; quantity: number }) => (
                      <div key={item.product.id} className="flex gap-3">
                        <div className="w-14 h-14 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                          <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm line-clamp-1">{item.product.name}</h4>
                          <p className="text-xs text-gray-500">الكمية: {item.quantity}</p>
                          <p className="text-sm font-medium text-[#7c3aed]">
                            {(item.product.price * item.quantity).toFixed(0)} ريال
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-500">المجموع الفرعي</span>
                      <span>{cartTotal.toFixed(2)} ريال</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">الشحن</span>
                      <span className={shippingCost === 0 ? 'text-green-500' : ''}>
                        {shippingCost === 0 ? 'مجاني' : `${shippingCost} ريال`}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>الإجمالي</span>
                      <span className="text-[#7c3aed]">{finalTotal.toFixed(2)} ريال</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
