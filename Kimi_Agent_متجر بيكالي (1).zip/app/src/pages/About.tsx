import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, Eye, Heart, Users, Award, TrendingUp, Shield } from 'lucide-react';

const values = [
  { icon: Heart, title: 'الجودة أولاً', description: 'نختار منتجاتنا بعناية فائقة لضمان أعلى معايير الجودة' },
  { icon: Users, title: 'رضا العملاء', description: 'نسعى دائماً لتجاوز توقعات عملائنا' },
  { icon: Shield, title: 'الثقة والشفافية', description: 'نؤمن ببناء علاقات طويلة الأمد مبنية على الثقة' },
  { icon: TrendingUp, title: 'الابتكار المستمر', description: 'نطور خدماتنا باستمرار لنواكب أحدث التقنيات' },
];

const stats = [
  { value: '50K+', label: 'عميل سعيد' },
  { value: '100K+', label: 'طلبية منجزة' },
  { value: '99%', label: 'نسبة الرضا' },
  { value: '24/7', label: 'دعم العملاء' },
];

export function About() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative py-20 lg:py-32 bg-gradient-to-br from-[#1a1a2e] to-[#7c3aed]/20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Badge className="mb-4 bg-[#7c3aed]">من نحن</Badge>
              <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
                نحن نصنع <span className="text-[#7c3aed]">تجربة تسوق</span> استثنائية
              </h1>
              <p className="text-lg text-gray-300 leading-relaxed">
                منذ تأسيسنا في عام 2020، نسعى جاهدين لتقديم أفضل تجربة تسوق إلكتروني
                في المملكة العربية السعودية.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 -mt-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="text-center">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-[#7c3aed] mb-1">{stat.value}</div>
                    <div className="text-sm text-gray-500">{stat.label}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <Card className="h-full">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7c3aed]/10 rounded-2xl flex items-center justify-center mb-6">
                    <Eye className="w-8 h-8 text-[#7c3aed]" />
                  </div>
                  <h2 className="text-2xl font-bold mb-4">رؤيتنا</h2>
                  <p className="text-gray-600 leading-relaxed">
                    أن نكون المنصة الرائدة للتجارة الإلكترونية في المملكة العربية السعودية،
                    نقدم تجربة تسوق فريدة تجمع بين الجودة العالية والخدمة الممتازة.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <Card className="h-full">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7c3aed]/10 rounded-2xl flex items-center justify-center mb-6">
                    <Target className="w-8 h-8 text-[#7c3aed]" />
                  </div>
                  <h2 className="text-2xl font-bold mb-4">مهمتنا</h2>
                  <p className="text-gray-600 leading-relaxed">
                    توفير منتجات عالية الجودة بأسعار منافسة، مع ضمان تجربة تسوق
                    سلسة وآمنة لجميع عملائنا.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">قيمنا</h2>
            <p className="text-gray-500">المبادئ التي توجهنا في كل ما نقوم به</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full text-center">
                  <CardContent className="p-6">
                    <div className="w-14 h-14 bg-[#7c3aed]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <value.icon className="w-7 h-7 text-[#7c3aed]" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{value.title}</h3>
                    <p className="text-sm text-gray-500">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">إنجازاتنا</h2>
            <p className="text-gray-500">فخورون بما حققناه على مر السنين</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {[
              { year: '2021', title: 'أفضل متجر إلكتروني ناشئ' },
              { year: '2022', title: 'شهادة ISO للجودة' },
              { year: '2023', title: 'أفضل خدمة عملاء' },
            ].map((award, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="text-center">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 bg-[#7c3aed]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Award className="w-8 h-8 text-[#7c3aed]" />
                    </div>
                    <Badge className="mb-2 bg-[#7c3aed]">{award.year}</Badge>
                    <h3 className="font-semibold">{award.title}</h3>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
