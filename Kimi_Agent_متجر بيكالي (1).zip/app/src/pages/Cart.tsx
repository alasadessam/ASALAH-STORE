import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  ShoppingCart,
  Trash2,
  Plus,
  Minus,
  ArrowLeft,
  Package,
  Truck,
  Shield,
} from 'lucide-react';

export function Cart() {
  const navigate = useNavigate();
  const { cart, removeFromCart, updateQuantity, getCartTotal } = useStore();

  const cartTotal = getCartTotal();
  const shippingCost = cartTotal > 500 ? 0 : 30;
  const finalTotal = cartTotal + shippingCost;

  if (cart.length === 0) {
    return (
      <div className="min-h-screen py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto text-center">
            <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="w-16 h-16 text-gray-400" />
            </div>
            <h1 className="text-2xl font-bold mb-3">السلة فارغة</h1>
            <p className="text-gray-500 mb-6">
              لم تضف أي منتجات للسلة بعد
            </p>
            <Button 
              className="bg-[#7c3aed] hover:bg-[#6d28d9]"
              size="lg" 
              onClick={() => navigate('/products')}
            >
              تصفح المنتجات
              <ArrowLeft className="w-5 h-5 mr-2" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">سلة التسوق</h1>
            <p className="text-gray-500">
              {cart.length} منتج | {cart.reduce((sum: number, item: { quantity: number }) => sum + item.quantity, 0)} قطعة
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            <AnimatePresence mode="popLayout">
              {cart.map((item) => (
                <motion.div
                  key={item.product.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                >
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        {/* Image */}
                        <div 
                          className="w-24 h-24 lg:w-32 lg:h-32 rounded-xl overflow-hidden shrink-0 bg-gray-100 cursor-pointer"
                          onClick={() => navigate(`/product/${item.product.id}`)}
                        >
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Details */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h3 
                                className="font-semibold text-lg mb-1 cursor-pointer hover:text-[#7c3aed] transition-colors line-clamp-1"
                                onClick={() => navigate(`/product/${item.product.id}`)}
                              >
                                {item.product.name}
                              </h3>
                              <p className="text-sm text-gray-500 mb-2">{item.product.category}</p>
                            </div>
                            <div className="text-left">
                              <p className="font-bold text-lg text-[#7c3aed]">
                                {(item.product.price * item.quantity).toFixed(0)} ريال
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between mt-4">
                            {/* Quantity */}
                            <div className="flex items-center border rounded-lg">
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 transition-colors"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span className="w-12 text-center font-medium">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 transition-colors"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>

                            {/* Remove */}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => removeFromCart(item.product.id)}
                            >
                              <Trash2 className="w-4 h-4 ml-2" />
                              حذف
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>

            <Button variant="outline" className="w-full" onClick={() => navigate('/products')}>
              <ArrowLeft className="w-4 h-4 ml-2" />
              مواصلة التسوق
            </Button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">ملخص الطلبية</h2>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-500">المجموع الفرعي</span>
                      <span>{cartTotal.toFixed(2)} ريال</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">الشحن</span>
                      <span className={shippingCost === 0 ? 'text-green-500' : ''}>
                        {shippingCost === 0 ? 'مجاني' : `${shippingCost} ريال`}
                      </span>
                    </div>
                    {shippingCost > 0 && (
                      <p className="text-xs text-gray-400">
                        أضف منتجات بقيمة {(500 - cartTotal).toFixed(0)} ريال للحصول على توصيل مجاني
                      </p>
                    )}
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>الإجمالي</span>
                      <span className="text-[#7c3aed]">{finalTotal.toFixed(2)} ريال</span>
                    </div>
                  </div>

                  <Button
                    className="w-full mt-6 bg-[#7c3aed] hover:bg-[#6d28d9]"
                    size="lg"
                    onClick={() => navigate('/checkout')}
                  >
                    إتمام الطلب
                    <ArrowLeft className="w-4 h-4 mr-2" />
                  </Button>
                </CardContent>
              </Card>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-2 mt-4">
                {[
                  { icon: Truck, label: 'توصيل سريع' },
                  { icon: Shield, label: 'دفع آمن' },
                  { icon: Package, label: 'دفع عند الاستلام' },
                ].map((item, index) => (
                  <div key={index} className="flex flex-col items-center text-center p-3 bg-gray-50 rounded-lg">
                    <item.icon className="w-5 h-5 text-[#7c3aed] mb-1" />
                    <span className="text-xs">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
