import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product, CartItem } from '@/types';

interface StoreState {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      cart: [],
      addToCart: (product: Product) => {
        const existingItem = get().cart.find((item: CartItem) => item.product.id === product.id);
        if (existingItem) {
          set({
            cart: get().cart.map((item: CartItem) =>
              item.product.id === product.id
                ? { ...item, quantity: item.quantity + 1 }
                : item
            ),
          });
        } else {
          set({ cart: [...get().cart, { product, quantity: 1 }] });
        }
      },
      removeFromCart: (productId: number) => {
        set({ cart: get().cart.filter((item: CartItem) => item.product.id !== productId) });
      },
      updateQuantity: (productId: number, quantity: number) => {
        if (quantity <= 0) {
          get().removeFromCart(productId);
        } else {
          set({
            cart: get().cart.map((item: CartItem) =>
              item.product.id === productId ? { ...item, quantity } : item
            ),
          });
        }
      },
      clearCart: () => set({ cart: [] }),
      getCartTotal: () => {
        return get().cart.reduce((total: number, item: CartItem) => {
          return total + item.product.price * item.quantity;
        }, 0);
      },
      getCartCount: () => {
        return get().cart.reduce((count: number, item: CartItem) => count + item.quantity, 0);
      },
      isCartOpen: false,
      setIsCartOpen: (open: boolean) => set({ isCartOpen: open }),
    }),
    {
      name: 'asalah-store',
      partialize: (state: StoreState) => ({ cart: state.cart }),
    }
  )
);
