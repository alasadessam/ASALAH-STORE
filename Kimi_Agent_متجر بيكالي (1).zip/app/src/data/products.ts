import type { Product, Category } from '@/types';

export const categories: Category[] = [
  { id: 'electronics', name: 'إلكترونيات', icon: 'Headphones', description: 'أحدث الأجهزة الإلكترونية' },
  { id: 'fashion', name: 'أزياء', icon: 'Shirt', description: 'أحدث صيحات الموضة' },
  { id: 'home', name: 'منزل وديكور', icon: 'Home', description: 'أثاث وأدوات منزلية' },
  { id: 'sports', name: 'رياضة ولياقة', icon: 'Dumbbell', description: 'معدات رياضية متنوعة' },
];

export const products: Product[] = [
  {
    id: 1,
    name: 'سماعات لاسلكية فاخرة',
    description: 'سماعات بلوتوث عالية الجودة مع صوت نقي وعميق',
    price: 299,
    originalPrice: 450,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
    category: 'electronics',
    rating: 4.8,
    reviews: 128,
    inStock: true,
    discount: 30,
  },
  {
    id: 2,
    name: 'ساعة ذكية رياضية',
    description: 'ساعة ذكية متعددة الوظائف مع تتبع اللياقة البدنية',
    price: 499,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600',
    category: 'electronics',
    rating: 4.6,
    reviews: 89,
    inStock: true,
    isNew: true,
  },
  {
    id: 3,
    name: 'حقيبة جلد طبيعي',
    description: 'حقيبة يد مصنوعة من الجلد الطبيعي الفاخر',
    price: 350,
    originalPrice: 500,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600',
    category: 'fashion',
    rating: 4.9,
    reviews: 156,
    inStock: true,
    isBestseller: true,
    discount: 30,
  },
  {
    id: 4,
    name: 'طقم أواني طهي',
    description: 'طقم كامل لأواني الطهي من الستانلس ستيل',
    price: 599,
    originalPrice: 899,
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=600',
    category: 'home',
    rating: 4.7,
    reviews: 78,
    inStock: true,
    discount: 33,
  },
  {
    id: 5,
    name: 'حذاء رياضي احترافي',
    description: 'حذاء رياضي عالي الأداء للجري والتمارين',
    price: 450,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600',
    category: 'sports',
    rating: 4.5,
    reviews: 203,
    inStock: true,
  },
  {
    id: 6,
    name: 'لابتوب احترافي',
    description: 'لابتوب عالي الأداء للأعمال والإنتاجية',
    price: 3499,
    originalPrice: 4299,
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600',
    category: 'electronics',
    rating: 4.8,
    reviews: 67,
    inStock: true,
    discount: 20,
  },
  {
    id: 7,
    name: 'أريكة مودرن',
    description: 'أريكة عصرية بتصميم أنيق ومريح',
    price: 1899,
    originalPrice: 2499,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600',
    category: 'home',
    rating: 4.6,
    reviews: 45,
    inStock: true,
    isNew: true,
    discount: 24,
  },
  {
    id: 8,
    name: 'بدلة رسمية',
    description: 'بدلة رجالية رسمية بقصة عصرية',
    price: 799,
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600',
    category: 'fashion',
    rating: 4.4,
    reviews: 92,
    inStock: true,
  },
];

export const getProductById = (id: number): Product | undefined => {
  return products.find((p) => p.id === id);
};

export const getProductsByCategory = (categoryId: string): Product[] => {
  return products.filter((p) => p.category === categoryId);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter((p) => p.isBestseller || p.isNew).slice(0, 4);
};
